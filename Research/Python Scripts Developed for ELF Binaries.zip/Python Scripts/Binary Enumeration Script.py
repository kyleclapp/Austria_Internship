import lief

binary = lief.parse("/home/kyle/Desktop/64_bit_test/64_bit_test")

def printheader ():
	print(binary.header)
	return



def printsegments ():
	for i in binary.segments:
		print(i)
	return


def printsections ():
	

	print('{:30} {:<20} {:<15}'.format("Section Name", "Virtual Address", "Section Size"))

	for t in binary.sections:
		print('{:30} {:<20} {:<15}'.format(t.name, t.virtual_address, t.size))
		

def print_contents_of_section(string):	
	print("\n\n------------------------------------------------------------------------")

	print("This is the content of the section specified\n\n")

	for i in binary.sections:
		if i.name == string:
			for data in i.content:
				print("{:x}".format(data), end=' ')
	
	for i in binary.sections:
		if i.name == string:
			print(i.size)
	return
	
def section_entropy ():
	
	print("\n\n------------------------------------------------------------------------")

	print("\n\nThe following sections names and their entropic values")


	print('{:30} {:20}'.format("Section Name", "Entropic level"))

	for s in binary.sections:
		print('{:30} {:<20}'.format(s.name, s.entropy))

		

def function_address (function):

	print("\n\n------------------------------------------------------------------------")

	print("This is getting the function address")

	print(binary.get_function_address(function))

		


	

def static_symbols ():

	print("\n\n------------------------------------------------------------------------")

	print("These are the static symbols \n\n")


	print('{:40} {:>20} {:>20} {:>10}'.format("Symbol Name", "VAddress","Hex Address", "Size"))

	for static_symbols in binary.static_symbols:
		if static_symbols.name == "":
			continue	
		print('{:40} {:20} {:>20} {:10}'.format(static_symbols.name, static_symbols.value,hex(static_symbols.value), static_symbols.size))


	print("------------------------------------------------------------------------")
	
	return


def dynamic_symbols ():
	
	print("\n\nThese are the dynamic symbols \n\n")

	for dynamic_symbols in binary.dynamic_symbols:
		print(dynamic_symbols)



	print("------------------------------------------------------------------------")
	
	return


def ro_symbols ():

	print("\n\nThese are the read only symbols \n\n")

	for symbols in binary.symbols:
		print(symbols)

	print("------------------------------------------------------------------------")

	return


def imported_symbols ():


	print("\n\nThese are the imported symbols\n\n")

	for imported_symbols in binary.imported_symbols:
		print(imported_symbols)

	print("------------------------------------------------------------------------")

	return


def  imported_functions ():


	print("\n\nThese are the imported functions\n\n")

	for imported_functions in binary.imported_functions:
		print(imported_functions)


	print("------------------------------------------------------------------------")

	return


def exported_functions ():

	print("\n\nThese are the exported functions\n\n")

	for exported_functions in binary.exported_functions:
		print(exported_functions)

	print("------------------------------------------------------------------------")

	return


def exported_symbols():

	print("\n\nThese are the exported symbols\n\n")

	for d in binary.exported_symbols:
		print(d)


	print("------------------------------------------------------------------------")



	


def virtual_address (start_address, size):

	print("\n\nContent at the virtual addresses\n\n")

	chrList = []
	

	content_at_location = binary.get_content_from_virtual_address(start_address,size)

	print(content_at_location)

	print("\n")

	for s in content_at_location:
		chrList.append(("{:x}".format(s)))
	

	for b in chrList:
		print(b, end=" ")

	print("\n")
	
	return


def dynamic_entries ():

	print("\n\n------------------------------------------------------------------------")
	
	print("\n\nThe dynamic entry locations")

	#for dynamic in binary.dynamic_entries:
		#print(dynamic)

	return	
	


def dynamic_relocation_data ():

	print("\n\n------------------------------------------------------------------------")

	print("\n\nThe dynamic relocation data")

	for dyn_relocation in binary.dynamic_relocations:
		print(dyn_relocation.type, dyn_relocation.symbol)
	
	return


def gnu_hash ():

	print("\n\n------------------------------------------------------------------------")
	
	print("The data of the gnu_hash")

	print(binary.gnu_hash)

	return

	








#This is the start of the function calls


printheader() #This prints the ELF Header file


printsegments() #This prints out the segments of the executable

printsections() #This prints the sections of binary


#print_contents_of_section(string = ".rodata")
###The following function is to print content of the section of the ELF file

###The section_entropy function looks at the sections and their entropy levels
###This might be interesting to apply this function when looking for encryption algorithms

#section_entropy()


#function_address(function = "max")   #This enumerates the address at which the given function is located at, the address returned is the same address that is returned inthe static_symbols method


static_symbols()    #This enumerates the static symbols


dynamic_symbols()    #This enumerates the dynamic symbols


ro_symbols()     #This is the read-only symbols that are being extracted


imported_symbols()  #These are the dynamic symbols that have been imported


imported_functions()   #These are the functions that have been imported


exported_functions()   #These are the functions that have been exported

exported_symbols()    #These are the symbols that have been exported

#virtual_address(start_address = 6299904, size = 4096)
###This function prints that contents at a specified address, the funtion "static_symbols" will return Virtual Address offsets for functions. The first arguement "start_address" is where the virtual address goes, the second argument "size" is how many bytes you would like to look at, please note as far as I can tell it will only take the virtual address and not the hex address


dynamic_entries()     #This prints the dynamic entries




dynamic_relocation_data()    #This prints the dynamic relocation data




#The following function is commented out as the gnu_hash feature serves little to no value in our investigation


#gnu_hash()   #This prints the hash of the function






#Symbol Version and the shndx function of the symbols are of little to no value in the context of what we are trying to look for














