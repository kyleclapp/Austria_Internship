import sys       #This imports sys, this allows the python to read the standard input from the pipe from the command line


import fileinput    #This is an alternative to the above method, if you have the assembly output saved in a file, this will allow the reading of the file line by line


import re #This enables python to use regular expressions


#Be sure to use the Intel syntax, the regex will not pick up AT&T syntax  
#This will only work if the function is called, if the function is not called in the binary then the script will throw and error

#This is the declaration of the function name, this can be any function that exists in the binary
function_name = "max"


#This is declaring the array that everything will be appended to
master_array = []

#This is intializing the counter and integer variables
line_counter = 0     #This keeps track of which line the program is on
line_of_match = 0    #When the regular expression finds a match, this variable is used to hold the line of the match as this will be used at another point of the function


#This is declaring the path to the file that will be used and opening the file
#This is only used if you would like to use a file and not standard input

#path = 'output.txt'    
#output = open(path,'r')

#For use with a file replace "for i in sys.stdin:" with "for i in output:"


for i in sys.stdin:   #This reads the standard input from the command line
	line_counter = line_counter + 1    #This increases the line_counter by one each line
	
	function_call_regex = re.match(r'(.*call.*)(.*'+re.escape(function_name)+r'.*)', i, re.M|re.I)     

#This regular expression is looking for a function call with the name of the function  declared above.

	
	if function_call_regex:   #If there is a match for the entire regex


		#The following print statement was used for testing purposes
		#The print statement can be uncommented to look at what the regular expression is looking for
		#print ("function_call_regex.group() : ", function_call_regex.group())   
		
		split_string = i.split(":")  

		#Because the location of the function call is beside a colon (":") this is splitting the regular expression string on a colon leaving 2 item array


		master_array.append(split_string[0].lstrip()) 

		#This is appending the data before the colon of the above regular expression to the array "master_array". At the same time it is also stripping the blank space in front of it.


 
		#print(master_array)  #This prints the location where the function was called
		#This print statement can be uncommented to see the content of the master_array so far
			
		
		address_of_function = re.sub('.*call|[^\w]|'+re.escape(function_name)+'',' ',i)	
		#This substitution command takes everything from the word call including the function name and replaces it with a null characater.   The "[^\w]" matches any non word characters
	



		address_of_function.lstrip()

		#This is stripping all the whitespace from the address of the function as it will be used later on 

		#At this point I have found the call address, I will now look for the arguements
		

		#print(address_of_function)
		#This print statement was used for testing, you can uncomment this to look at results of the substitution string
		

	


	#This is finding the location of the function in the code 
	function_location_regex = re.match( r'(.*[a-f|A-F|0-9]{16}) (.*<'+re.escape(function_name)+'>.*)', i, re.M|re.I)

	#This looks for the function call, it looks for 16 hex characters following by the function name in between <>, example <max> given max is the function name. This works on unstripped binaries as the name of the function  is still there. 
	
	#For stripped binaries, if you know the function call location, you can modify this regular expression to look for an absolute hex address

	if function_location_regex:
	#If there is a match for the function call
		
		#print(function_location_regex.group())
		#This was used for testing purposes, this prints the strings that the regular expression finds
		
		function_location = function_location_regex.group()
		#This assigns the function variable the value from the regular expression 


		line_of_match = line_counter
		#This keeps track of which line the match took place on



	#This is looking for the mov commands along with WORD of BYTE as this indicates and arguement being pushed	
	arguement_regex = re.match( r'(.*[mov|fld].*)(.BYTE|WORD) (PTR.*])', i, re.M|re.I)
	#This looks for any opcode with mov or fld (fld is used for moving long double variable types)
	#It then looks for anything with BYTE of WORD in the Intel syntax  followed by pointer as all three of these indicate that a variable has been pushed

	
	if arguement_regex:
	#This checks if there is a match
	

		difference = line_counter - line_of_match
		#This calculates how for past there was a match for the regular expression 	


		if difference < 9:

		#The difference counter indicates how far past the function to look for arguments being pushed, as arguements being pushed to the stack should only occur within the first few lines.
		#By limiting this number this should limit the amount of false positives that occur 


			#The following is getting the arguements from the assembly code  and assigning them to the value arguements


			#The print statement below was used for testing purposes
			#print(arguement_regex.group())	
			arguements = arguement_regex.group()


			#This if statement looks for the address of the function instance in the function location string. This matches the function call to the correct instance of the function definition. This will prevent the program from looking at the wrong function definition while looking at function arguements 			
			if function_location.find(address_of_function):
				#print("This if statement worked")   #This was used for testing purposes

				if " BYTE" in  arguements:
					#This was used for testing, can be commented out
					#print("This contains the string BYTE")
					master_array.append(1)

				elif " WORD" in  arguements:
					#This was used for testing, can be commented out
					#print("This contains the string WORD")
					master_array.append(2)

				elif " DWORD" in  arguements:
					#This was used for testing, can be commented out
					#print("This contains the string DWORD")
					master_array.append(4)

				elif " QWORD" in  arguements:
					#This was used for testing, can be commented out
					#print("This contains the string QWORD")
					master_array.append(8)
			
				elif " TBYTE" in  arguements:
					#This was used for testing, can be commented out
					#print("This contains the string TBYTE")
					master_array.append(10)
				
				#This if statement looks for the string patterns in double quotations and appends the correct length of variable to the master_array.


print(master_array)

#This prints the master_array with all of its elements












		
	

