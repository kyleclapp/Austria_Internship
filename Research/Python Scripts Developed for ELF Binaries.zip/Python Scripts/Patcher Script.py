import lief

binary = lief.parse("/home/kyle/Desktop/Working_iteration_arguements/inserted_function")


#This script is used to patch data into the binary
#The first PATCH has been commented as an explanation


#PATCH1
#==========================================================================

#STEP 1
data1 = "\x90"   



#Inside the quotation marks is to contain the hex data that will be patched into the binary

#The hex data has to be inputted in the manner you above, all hex characters have to inputted with the "\x" prefix to indicate to python that it is a hex character. Example seen above


#STEP 2
dataList1 = []

#This is declaring the array that the hex data will be put into in order for LIEF to handle it


#STEP 3
for i in  data1:
	dataList1.append(ord(i))

#This for loop is iterating through every character that was provided as data above (STEP 1) and entering the data into the array that was declared (STEP 2). The reason that the data is being cast using "ord()" (Unicode representation) is that when LIEF inserts the data, LIEF inserts the data as the ASCII representation of the integer provided



#STEP 4
binary.patch_address(4195656, dataList1)

#This is actually patching the data into the binary. The first arguement, in this case "4195656" is the integer representation of the hex value of the location that you want to patch/write over. This parameter is to be given as an integer as seen above. The second arguement is an array of data that you will be used to patch over the given address. This is the data that was provided in STEP 1 and put into and array (STEP 1 and STEP 2)


#Below are  patches 2-10, you can create more or delete some depending on the situation at hand

#PATCH2
#==========================================================================

data2 = ""
dataList2 = []

for s in  data2:
	dataList2.append(ord(s))

binary.patch_address(4190786, dataList2)

#PATCH3
#==========================================================================

data3 = ""
dataList3 = []



for q in data3:
	dataList3.append(ord(q))

binary.patch_address(4190791, dataList3)


#PATCH4
#==========================================================================

data4 = ""
dataList4 = []

for t in data4:
	dataList4.append(ord(t))

binary.patch_address(4190778, dataList4)

#PATCH5
#==========================================================================

data5 = ""
dataList5 = []


for y in data5:
	dataList5.append(ord(y))

binary.patch_address(4190796, dataList5)

#PATCH6
#==========================================================================

data6 = ""
dataList6 = []

for r in data6:
	dataList6.append(ord(r))

binary.patch_address(4190808, dataList6)


#PATCH7
#==========================================================================


data7 = ""
dataList7 = []

for e in data7:
	dataList7.append(ord(e))

binary.patch_address(4195699, dataList7)


#PATCH8
#==========================================================================

data8 = ""
dataList8 = []

for o in data8:
	dataList8.append(ord(o))
binary.patch_address(4190776, dataList8)


#PATCH9
#==========================================================================

data9 = ""
dataList9 = []

for p in data9:
	dataList9.append(ord(p))

binary.patch_address(4190851, dataList9)


#PATCH10
#==========================================================================

data10 = ""
dataList10 = []


for a in data10:
	dataList10.append(ord(a))

binary.patch_address(4190851, dataList10)



#The following line of code is writing a binary file that will contain the changes made above. 
#This name can be changed to anything and the file will be written in the same directory as this script if just the name of the file is given. You can provide an absolute path for more control if that is desired. 
#This name can also be the same as the file that is being modified so that the changes overwrite the original file.

binary.write("moddified")




