import lief
#This imports the LIEF library, make sure that you have installed version 3.5


#This is the path to the binary that be used for modification, this can be changed to any absolute path

binary = lief.parse("/home/kyle/Desktop/testing")


#This is declaring the array that will be used to hold the data that will used as the section data.

dataList1 = []


#The data that will be used as the section data. ****Please note how the data is formatted. All the data is a string literal with the "\x" indicating to python that it is hex character. I have experimented with inserting extremely large strings of hex data as the section content and the binary was still able to run. 

data1 = "\x8b\x45\xf4\x89\xc6\xbf\xe4\x05\x40\x00\xb8\x00\x00\x00\x00\xe8\xa9\xfe\xff\xff\x8b\x45\xf8\x89\xc6\xbf\xe4\x05\x40\x00\xb8\x00\x00\x00\x00\xe8\xa9\xfe\xff\xff\x8b\x45\xfc\x89\xc6\xbf\xe4\x05\x40\x00\xb8\x00\x00\x00\x00\xe8\xa9\xfe\xff\xff\xc9\xc3"




#This adds the data to the array that was declared above. ****Please note that the data is appended cast with "ord()" as a unicode integer as LIEF adds the data to the binary as the ASCII equivalent. 
for f in data1:
	dataList1.append(ord(f))



#This is creating the section that will be added to the binary 

section           = lief.ELF.Section() # Creating a section object called "section"
section.name      = ".text" #Assigning the name of the section to the attribute called ".name"
section.type      = lief.ELF.SECTION_TYPES.PROGBITS #This is declaring the type of section
#Please refer to the API page of the LIEF documentation for all the available types

section.flags     = lief.ELF.SECTION_FLAGS.ALLOC | lief.ELF.SECTION_FLAGS.EXECINSTR
#The flags being set to the attribute ".flags"
#Please refer to the API page of the LIEF documentation for all the available types

section.data      = dataList1 #Making the section's content the value of data
section.alignment = 8 #The alignment the section will have
section.size      = 512 #The allotted size that the section will have
section.virtual_address = 6295638 #The virtual_address the section will have
#I found that setting the value of the virtual address does not make a difference as it will always be appended to the end of the binary

#For the "alignment" and "size" attributes I found that the values do not matter for them, they just act as a placeholder from my experience as i could not set the values and nothing would change

binary.add_section(section, True)

#This is adding the section to the binary. The first parameter is the section object that was created above. The second parameter is a Boolean value.
#True means that the section will be loaded as an executable like a conventional ".text" would be that contains runnable code and has the flags "Read" and "Execute"




binary.write("inserted_function")

#This is writing the function to the name provided in quotation marks. This can be changed to an absolute path









