# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 10:44:50 2018

@author: Kyle
"""

import numpy as np
import pandas as pd
from sklearn.cross_validation import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn import tree
import matplotlib.pyplot as plt
import graphviz 

dataset = pd.read_csv('sonar.all-data')

values = []

counter = 0

Rocks = []
Mines = []
#There are 97 rows of R, this is what I used to get the averages of the data

with open('sonar.all-data', 'r') as file:
    
        for line in file:
            row = line.split(",")
            counter = counter + 1
            if (counter < 98):
                                      
                for x in row[:-1]:
            
                    Rocks.append(x)
            
            else:
                
                for x in row[:-1]:
            
                    Mines.append(x)
file.close()   #closing the file that we read from 

################################################### Getting the average of the Rock Data

length_Rocks = len(Rocks)
print(length_Rocks)
sum_Rocks = 0


for  i in range(len(Rocks)):
   
    sum_Rocks = sum_Rocks + float(Rocks[i])
   
print("This is the sume of all the values for the Rocks", sum_Rocks)
print("This is the average of the rock data",sum_Rocks/len(Rocks))

###################################################  Getting the average of the Mine data

length_Mines = len(Mines)
print(length_Rocks)
print(length_Mines)

sum_Mines = 0
for  i in range(len(Mines)):
    #print(Rocks[i]) ##This was used for testing purposes
    sum_Mines = sum_Mines + float(Mines[i])
   
print("This is the sume of all the values for the Rocks", sum_Mines)
print("This is the average of the rock data",sum_Mines/len(Mines))

###################################################

#This is where we can visualize the data

#print("This is visualinzing the data", dataset.head(), "\n\n\n") 
  
'''The line above this needs to uncommented before submitting'''

#Here I will use some classification algorithms and classify the data, Rocks vs Mines

#Given a set of signal strengths, attempt to guess whether or not the data is from a rock or a mine


###################
#This is creating training and datasets for the data
#This is preparing the dataset for machinie learning


train, test = train_test_split(dataset, test_size=0.2, random_state=42) #This is splitting the dataset
train_labels = train.iloc[:,-1]    #This is selecting the last row as this is the column that we want to predict
train_data = train.drop(train.columns[[-1]], axis=1)  #This is dropping the last column that we want to find
test_labels = test.iloc[:,-1]  #This is selecting the last row as this is the column that we want to predict
test_data = test.drop(test.columns[[-1]], axis=1)  #Dropping the columns that are not needed

#print("Thse are the training labels",train_labels)   #These are for testing purposes
#print("Thse are the testing labels",test_labels)  #These are for testing purposes

# For multiclass classification, we will use 'Hobby' as the target
train_labels_mc = train['R']
#test_labels_mc = test['Hobby']


###################
###################This is standardizing the data

#Standardize data so it has mean = 0 and variance = 1
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(train_data)
print(scaler.mean_)
train_data_standardized = scaler.transform(train_data) #This is standardizing the training data


#scaler.fit(test_data) # Don't! You want to standardize using the training data only
test_data_standardized = scaler.transform(test_data)  #This is standardizing the test data

###################
###################This performs the classification of the data

# I will use the  Stochastic Gradient Descent 
from sklearn.linear_model import SGDClassifier
sgd_clf = SGDClassifier(random_state=42, max_iter=3)
sgd_clf.fit(train_data_standardized, train_labels)


###################

#This works
#prediction = sgd_clf.predict(test_data_standardized)
# Compare these predications against the actual values (test_labels)
#print('Predictions:', prediction) 

#This works
#from sklearn.model_selection import cross_val_score  #This is importing the dat cross validation function
#scores = cross_val_score(sgd_clf, train_data_standardized, train_labels, cv=3, scoring="accuracy")  #This is how many times the data should be split and tested for the machine learning algorithm
#print('Score for each fold:', scores)


#This works
#from sklearn.model_selection import cross_val_predict
#y_train_pred = cross_val_predict(sgd_clf, train_data_standardized, train_labels, cv=3)
#from sklearn.metrics import confusion_matrix
#print('Confusion matrix:', confusion_matrix(train_labels, y_train_pred))


#This does not work for reasons I do not know

#from sklearn.metrics import precision_score, recall_score
#print('Precision:', precision_score(train_labels, y_train_pred))
#print('Recall:', recall_score(train_labels, y_train_pred))

#This does not work either

#from sklearn.metrics import f1_score
#print('F1 Score:', f1_score(train_labels, y_train_pred))


sgd_clf.fit(train_data_standardized, train_labels_mc)
random_value = np.random.randint(0, 50) 
print('Predicted:',sgd_clf.predict(train_data_standardized[random_value,0:].reshape(1,-1)))
print('Actual:',train.iloc[random_value][60])
some_person_scores = sgd_clf.decision_function((train_data_standardized[random_value,0:].reshape(1,-1)))


print("\n\n\n\n This is the non reshaped array",train_data_standardized[random_value,0:])

print("\n\n\n\n This is the reshaped array",train_data_standardized[random_value,0:].reshape(1,-1))

print("This is the test set", train)

