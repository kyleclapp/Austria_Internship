# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 10:44:50 2018

@author: Kyle
"""

import numpy as np
import pandas as pd #Pandas creates a dataframe 
import matplotlib.pyplot as plt   #This plots the data to the user

dataset = pd.read_csv('wine.dat')  #This reads the dataset into a dataframe


#This selects the columns that the scatter matrix will be produced from.
df = pd.DataFrame(dataset, columns=['Alcohol', 'Malic acid', 'Ash', 'Magnesium']) 

#This is creating the scatter matrix with several arguments
spm = pd.plotting.scatter_matrix(df, alpha=0.2, figsize=(6, 6), diagonal='hist')

#This printing the histogram to the user
plt.show()