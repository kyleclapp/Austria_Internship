# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 10:44:50 2018

@author: Kyle

When completing this question, I realized the wine dataset was built in to
sklearn and sklearn could prepare the data for me. I completed the question
with sklearn and did it a manual way as well as letting sklearn automatically 
prepare the dataset for me. I have generated both graphs to show my work.
"""

#This is importing all the libraries that are needed to make the decision tree
	
import numpy as np
import pandas as pd
from sklearn.cross_validation import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn import tree
import graphviz 

############This is the preparing the dataset manually
#This is reading the dataset into a variable
dataset = pd.read_csv('wine.dat')

#Selecting the columns which are most influential on the dataset, in this case it is everything but the alcohol content column as the alcohol content column is the label that we are trying to predict
X = dataset.values[:, 1:13]   #Manually preparing the dataset
#This is setting the label that we are trying to predict with the binary decision tree
Y = dataset.values[:, 0]      #Manually preparing the dataset


#This is splitting the data into test and training, with the test size being 20% and the learning size 80% with 100 random selection of values are chosen to train and test
X_train, X_test, y_train, y_test = train_test_split( X, Y, test_size = 0.2, random_state = 100) 
#This is creating the decision tree, gini!#!##!# figure this out, % random and a max_depth set to 4 so we get 3 stages of leaf nodes
clf_gini = DecisionTreeClassifier(criterion = "gini", random_state = 100, max_depth=3)
#This trains the decision tree on the training data
clf_gini.fit(X_train, y_train)


#This is exporting the graph to a pdf for easier viewing
dot_data = tree.export_graphviz(clf, out_file=None, feature_names=wine.feature_names, class_names=wine.target_names,filled=True, rounded=True,  special_characters=True) #Most of these parameters are not needed as they colour co-ordinate the graph but they do help visualizing the dataset better
#This creates the graphs from the exported data
#The website that I had found to help me allowed me to add colours to the decision tree
graph = graphviz.Source(dot_data) 
#This renders the final decision tree
graph.render("wine_manual_preparation")


#############This is sklearn automatically preparing the dataset



from sklearn.datasets import load_wine

wine = load_wine()
clf = tree.DecisionTreeClassifier(criterion = "gini", random_state = 100, max_depth=3)
clf = clf.fit(wine.data, wine.target) #This is letting SKLearn automatically prepare the dataset

 
dot_data = tree.export_graphviz(clf, out_file=None, feature_names=wine.feature_names, class_names=wine.target_names,filled=True, rounded=True,  special_characters=True) 
graph = graphviz.Source(dot_data) 
graph.render("wine_automatic_preparation") 



