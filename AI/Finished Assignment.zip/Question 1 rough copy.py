
import matplotlib.pyplot as plt
from sklearn import linear_model
import numpy as np
data = open('attributes_vs_salary.dat', 'r')

xList = []
labels = []
names = []

#-------------------
#This is the code from the lecture to split the arrays
firstLine = True
for line in data:
    if firstLine:
        names = line.split(",")   #This is putting the names of the columns into there own array
        firstLine = False  #This is setting the flag to false so that it will not overwrite the names array
    else:
        #split on comma
        row = line.split(",")
        #put labels in separate array
        labels.append(float(row[-1]))    #This is setting names on the Y-axis
        #convert row to floats
        xList.append(float(row[1]))      #This is setting names on the x-axis 

data.close()   #closing the file that we read from 

#-------------------------------------------

#####This is the code that I wrote
#import numpy as np
#import pandas as pd
#import matplotlib.pyplot as plt

#dataset = pd.read_csv('attributes_vs_salary.dat')
#plt.scatter(dataset['GPA'],dataset['Income ($K/year)'])
#plt.show()

#with open('attributes_vs_salary.dat', 'r') as f:
#    for line in f:
        #print(line)     #This was used for testing purposes
        


#############This is plotting the data manually
#Another way that I can plot the points on the graph

#row = line.split('')       This will split the data into rows



#plt.scatter[xList, labels, color='red']
#plt.plot(x,y)
#plt.x(0,30)
#plt.y(0,200)
#############


    
#Is this how to find the mean square of the dataset?
#Is there a method to find this using numpy?

#For all the stats functions, do we have to program them ourseilves

#1.    Find the regression line.
#1.    Insert your X values into the linear regression equation to find the new Y values (Y’).
#1.    Subtract the new Y value from the original to get the error.
#1.    Square the errors.
#1.    Add up the errors.
#1.    Find the mean.

#I might be able to get the software to do this for me, this is all defined in the example MVM gave us
#In MVM's code, it prints the error for us, do we need to print the errors out?


#####    This is my code that I wrote

########This is the code that MVM wrote to plot it manually
# Plot points
plt.scatter(xList, labels, color = 'b')
plt.xlabel("years of education")
plt.ylabel("salary (in K$)")

# Two guesstimate models:
#plt.plot([0, 31],[45, 200], 'r--') #pred=45+5x; T0=45, T1=5 
#plt.plot([0, 31],[65, 130], 'g-.') #pred=65+2.1x; T0=45, T1=2.1; 

# A linear regression model finds the "best" fitting Thetas

############This is figuring out the line of best fit, we need to do this to figure out the mean square difference

model = linear_model.LinearRegression()

# Train linear model to obtain best Theta0 and Theta1
# But first turn lists into arrays, this allows us to work with the numbers
X = np.c_[xList]
y = np.c_[labels]
model.fit(X,y)

pred = model.predict([[31]])
x_pred = [0, 31]
y_pred = [model.intercept_[0], pred[0,0]]
plt.plot(x_pred, y_pred, 'k', lw='5')

print('Theta0 = ', model.intercept_[0], ', Theta1 = ', model.coef_[0,0])

# Now suppose you have a new student for whom you want to predict salary
############This is using the line of best fit for guessing what the salary will be
new_years_of_education = [[15]] 
print(model.predict(new_years_of_education))
plt.plot(new_years_of_education, model.predict(new_years_of_education), marker='s', color='red')

plt.show()  #This is showing the how the guestimation will fit on the line of best fit



prediction = model.predict(X).flat  #X in this case are the X-Axis values
error = []    #This is the array that holds the values for the error
for i in range(len(labels)):
    error.append(labels[i] - prediction[i])  #This is the error value, subtracting the guessed model from the actual data for the corresponding X-value

#print the errors
print("Errors ",)####This is simply printing the errors
print(error)

#calculate the squared errors and absolute value of errors
squaredError = []
absError = []
for val in error:
    squaredError.append(val*val)  ##This is the squared error, just squaring the values
    absError.append(abs(val))  ##This is just getting the absolute value of the corresponding error

#print squared errors and absolute value of errors
print("Squared Error")
print(squaredError)   ##Printing the squared errors
print("Absolute Value of Error")
print(absError)  ##Printing the absolut errors

#calculate and print mean squared error MSE
print("MSE = ", sum(squaredError)/len(squaredError))  ###Adding up the contents of the array, then dividing by how many items in the array to get the mean

from math import sqrt
#calculate and print square root of MSE (RMSE)
print("RMSE = ", sqrt(sum(squaredError)/len(squaredError)))   ##This is getting the mean of the squared error

#calculate and print mean absolute error MAE
print("MAE = ", sum(absError)/len(absError))    ##This is getting the mean of the absolute error

#compare MSE to target variance
targetDeviation = []
targetMean = sum(labels)/len(labels)
for val in labels:
    targetDeviation.append((val - targetMean)*(val - targetMean))  ##Comparing the values that were produced and comparing them to actual values

target_variance = sum(targetDeviation)/(len(targetDeviation)-1)   ##Getting the target variance
#print the target variance
print("Target Variance = ", target_variance)

target_std = sqrt(target_variance)   ##This is just getting the square root of the target variance
#print the the target standard deviation (square root of variance)
print("Target Standard Deviation = ", target_std)