# -*- coding: utf-8 -*-
"""
Created on Tue Jan 30 10:44:50 2018

@author: Kyle
"""

import pandas as pd  #Pandas allows for easy importing of the data and creates a dataframe


dataset = pd.read_csv('MNIST.dat.csv') #This reads the dataset into memory for it to be worked with, windows likes to hide file extensions, I needed the second extension for it to read the file in windows

print(dataset.head())  #This shows the head of the dataset that is being worked with