# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 14:50:24 2018

@author: Clifford Kyle Clapp, Ian Wei, Marcu Capota

"""

"""
Citations:
We have taken code from MVM and modified it for our application, we do not claim this code as our own
We have also taken code samples from SKlearn documentation at:
http://scikit-learn.org
"""

#This is importing all the required libraries
import numpy as np
import pandas as pd
from sklearn.cross_validation import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import matplotlib.pyplot as plt
import graphviz 
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import SGDClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import cross_val_score
from sklearn.gaussian_process import GaussianProcessClassifier


'''
This is importing the data
'''
dataset = pd.read_csv('clean_dataset.csv')    #This is importing the dataset, make sure to have the dataset saved in the same directory

#print(dataset.head) #This is used for testing purposes to see the contents of the dataset


'''
This is creating a decision tree
'''
'''  The following code was taken from MVM's code   '''
X = dataset.iloc[:, 0:29] #This is selecting the attributes
Y = dataset.iloc[:, -1] #This is selecting the labels 
#print(X)  #This was used for testing purposes
#print(Y)  #This was used for testing purposes

'''  The following code was taken from MVM's code   '''
X_train, X_test, y_train, y_test = train_test_split( X, Y, test_size = 0.2, random_state = 100) #This is splitting the dataset apart into training and testing dataset
clf_gini = DecisionTreeClassifier(criterion = "gini", random_state = 100, max_depth=5) #This is creating the decision tree classifier
clf_gini.fit(X_train, y_train) #This firrint the training data into the decision tree

'''   The following code was taken from http://scikit-learn.org  '''
dot_data = tree.export_graphviz(clf_gini, out_file=None, filled=True, rounded=True, special_characters=True) #This is exporting the graph as well as passing parameters to the graph so it has colours
graph = graphviz.Source(dot_data)   #This is loading the decision tree so it can be displayed in Spyder
graph.render("final_project_decision_tree") #This is rendering the graph in Sypder

#This decision tree looks works like a champ

'''
This is classifying the data into training and testing datasets and having the algorithm guess
'''

# Create training/testing datasets and cropping them
'''  The following code was taken from MVM's code   '''
train, test = train_test_split(dataset, test_size=0.2, random_state=42) #This is splitting data into training and testing datasets for the classification algorithms
training_labels = train.iloc[:,-1]   #This is formatting the data into attributes and labels
training_data = train.drop(train.columns[[-1]], axis=1) #This is formatting the data into attributes and labels
testing_labels = test.iloc[:,-1]  #This is formatting the data into attributes and labels
testing_data = test.drop(train.columns[[-1]], axis=1)  #This is formatting the data into attributes and labels

'''  The following code was taken from MVM's code   '''
train_labels = train['Result']   #This is setting the labels to the column name
test_labels = test['Result']    #This is setting the labels to the column name

#print("These are the training_labels", testing_labels)  #This was used for testing purposes

#print(train_labels) #This was used for training purposes

'''  The following code was taken from MVM's code   '''
scaler_function = StandardScaler()     #This is creating a Scaler object that can standardize the data
scaler_function.fit(training_data)     #This is standardizing the training data

standardized_training_data = scaler_function.transform(training_data)  #This is transforming the training data and making assigning to a new variable
standardized_testing_data = scaler_function.transform(testing_data) #This is standardizing the testing data

SGD_classifier = SGDClassifier(random_state=42, max_iter=3)  #Setting the parameters for the classification algorithm
SGD_classifier.fit(standardized_training_data, training_labels) #This is fitting the scaled training data to the model

prediction = SGD_classifier.predict(standardized_testing_data)  #This is actually making the code predict something
random_value = np.random.randint(0, 50)   #This is selecting a random value to test with


'''  The following code was taken from MVM's code   '''
#print('Predicted:',SGD_classifier.predict(standardized_testing_data[random_value,0:].reshape(1,-1))) #This is making the prediction, this is reforming the array so that it works with the it is a single array
#print('Actual:',test.iloc[random_value][30]) #This is printing the actual value, this is either a rock or a mine
print("\n\n\n")


'''   The following code was taken from http://scikit-learn.org  '''
'''  This is the SGD classifier  '''
SGD_scores = cross_val_score(SGD_classifier, standardized_training_data, training_labels, cv=10, scoring="accuracy") #This is creating the classification object for SGD
print("SGD cross validation scores:", SGD_scores) #This is printing the scores
print("SGD average accuracy: ", sum(SGD_scores)/len(SGD_scores), "\n") #Printing the average of the scores




'''  Need to adjust if which dataset this chooses from, the code is from MVM's classification code   '''


'''   The following code was taken from http://scikit-learn.org  '''
'''  This is the gaussian classifier  '''
gaussian_classifier = GaussianProcessClassifier(optimizer = 'fmin_l_bfgs_b', max_iter_predict=1)
gaussian_scores = cross_val_score(gaussian_classifier, standardized_training_data , training_labels, cv=10, scoring="accuracy") #This is creating the classification object for gaussian
print("Guassian cross validation scores", gaussian_scores) #This is printing the scores
print("Guassian average accuracy: ", sum(gaussian_scores)/len(gaussian_scores), "\n")  #Printing the average of the scores


'''   The following code was taken from http://scikit-learn.org  '''
'''  This is the nueral network classifier  '''
neural_classifier = MLPClassifier(solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(5,4,3))
neural_scores = cross_val_score(neural_classifier, standardized_training_data , training_labels, cv=10, scoring="accuracy") #This is creating the classification object for Neural Networks
print("Neural Network cross validation scores", neural_scores) #This is printing the scores
print("Neural Network average accuracy: ", sum(neural_scores)/len(neural_scores), "\n") #Printing the average of the scores




''' A function to see how accurate the most influential attribute is  '''
prune1 = dataset.drop(dataset.columns[0:6], axis=1) #Cropping the data  for the function
pruned_dataset = prune1.drop(prune1.columns[1:24], axis=1) #The dataset with only 2 columns left
      
#The pruned dataset is onlt column 7 and the result   
#0 is suspciious
#-1 is Malicious

subdomain = []   #initialinzing an array
result = []    #initialinzing an array

subdomain = pruned_dataset.iloc[:,0]  #Assigning a column from the pandas dataframe to an array
result = pruned_dataset.iloc[:,1]     #Assigning a column from the pandas dataframe to an array

malicious_counter = 0   #Initialing a counter
suspicious_counter = 0   #Initialing a counter

for q in range(len(subdomain)):     #For loop to count through all the samples
    if (subdomain[q] == -1):   #if statement for the attribute
        suspicious_counter = suspicious_counter + 1 #Increasing the counter if the above if statement is true
    
    if (result[q] == 1): #if statement for the result
        malicious_counter = malicious_counter + 1 #Increasing the counter if the above if statement is true

#print(suspicious_counter) #This is used for testing purposes
#print(malicious_counter) #This is used for testing purposes

percentage = suspicious_counter/malicious_counter  #This is calculating how accurate the most influential attribute is 
#print("This is the percentage: ", percentage)   #This is printing the precentage that the attribute is

''' This is creating a PCA analysis diagram    '''

'''  The following code was pulled from MVM's code   '''
pca = PCA(n_components = 2)    #This is setting the amount of components that we want to use
X2D = pca.fit_transform(training_data)   #Fit_transform turn the 3d kinto 2d values
plt.scatter(X2D[:,0], X2D[:,-1]) #Assigning the X and Y values for the scatter plot
plt.xlabel('1st component')  #The X label
plt.ylabel('2nd component')  #The Y label












